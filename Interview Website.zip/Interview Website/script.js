function showhide(box) {
  $(box).toggleClass('answerClosed');
  $(box).toggleClass('answerOpen');
};


